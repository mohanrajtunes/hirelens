(function(){
var d=document,root=d.documentElement;root.classList.add('js');
var $=function(s){return d.querySelector(s)},$$=function(s){return [].slice.call(d.querySelectorAll(s))};
var reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
var fine=matchMedia('(pointer:fine)').matches;

/* ---------- blue ripple texture ---------- */
var canvas=$('#bg'),lensEl=$('#lens'),gl=null;
var mouse={x:innerWidth*.6,y:innerHeight*.5},lens={x:mouse.x,y:mouse.y,r:0,tr:0};
try{gl=canvas.getContext('webgl',{antialias:false,alpha:false})}catch(e){}
if(gl){try{
  var vs='attribute vec2 a;void main(){gl_Position=vec4(a,0.,1.);}';
  var fs=[
  'precision highp float;',
  'uniform vec2 R;uniform float T,S,DPR;uniform vec2 M;uniform float LR;',
  'const vec3 NAVY=vec3(.031,.063,.341),DEEP=vec3(.082,.29,.765),MID=vec3(.067,.475,.863),BRI=vec3(.075,.545,.902),SKY=vec3(.6,.78,.925);',
  'float h(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}',
  'float n(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h(i),h(i+vec2(1,0)),f.x),mix(h(i+vec2(0,1)),h(i+vec2(1,1)),f.x),f.y);}',
  'float fbm(vec2 p){float v=0.,a=.5;for(int i=0;i<3;i++){v+=a*n(p);p=p*2.07+3.1;a*=.5;}return v;}',
  'float th(float x){x=clamp(x,-9.,9.);float e=exp(2.*x);return (e-1.)/(e+1.);}',
  'vec3 tex(vec2 uv){',
  ' float asp=R.x/R.y; vec2 p=uv-vec2(asp*.5,.5);',
  ' float cx=-.08*asp+.26*sin(p.y*1.45+T*.11+S*.75)+.09*sin(p.y*3.2-T*.08+S*.4)+.06*(fbm(vec2(p.y*1.3,T*.05))-.5);',
  ' float x=p.x-cx;',
  ' float w=8.5*(x+.22*th(x*6.))+.9*fbm(p*1.3+vec2(0.,T*.04))-T*.15;',
  ' float f=fract(w);',
  ' float pr=pow(1.-f,1.25)*smoothstep(0.,.16,f);',
  ' pr=mix(pr,.5+.5*cos(6.2832*(f-.1)),.35);',
  ' float ax=abs(x);',
  ' pr=mix(.55,pr,mix(1.,.45,smoothstep(.15,.85,ax)));',
  ' vec3 col=mix(DEEP,BRI,pr);',
  ' col+=SKY*pow(pr,7.)*.75*(1.-smoothstep(.05,.6,ax)*.6);',
  ' float cr=exp(-x*x*9.);',
  ' col=mix(col,NAVY,cr*(1.-.6*pr)*.95);',
  ' col=mix(col,MID,smoothstep(.35,1.,ax)*.35);',
  ' return col;}',
  'void main(){',
  ' vec2 uv=gl_FragCoord.xy/R.y; vec2 m=M/R.y; float lr=LR/R.y;',
  ' float dl=length(uv-m); float ins=lr>0.?smoothstep(lr,lr-.003,dl):0.;',
  ' float bend=ins*(1.-pow(dl/max(lr,.001),2.))*.35;',
  ' vec2 q=mix(uv,m+(uv-m)*(.42-bend*.2),ins);',
  ' vec3 col=tex(q);',
  ' col*=1.-.1*ins;',
  ' vec2 v=gl_FragCoord.xy/R-.5; col*=1.-.18*dot(v,v);',
  ' col+=(h(gl_FragCoord.xy+fract(T*7.)*31.)-.5)*.035;',
  ' gl_FragColor=vec4(col,1.);}'
  ].join('\n');
  function sh(t,s){var o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);if(!gl.getShaderParameter(o,gl.COMPILE_STATUS))throw gl.getShaderInfoLog(o);return o}
  var pr=gl.createProgram();gl.attachShader(pr,sh(gl.VERTEX_SHADER,vs));gl.attachShader(pr,sh(gl.FRAGMENT_SHADER,fs));gl.linkProgram(pr);gl.useProgram(pr);
  var b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),gl.STATIC_DRAW);
  var al=gl.getAttribLocation(pr,'a');gl.enableVertexAttribArray(al);gl.vertexAttribPointer(al,2,gl.FLOAT,false,0,0);
  var U={};['R','T','S','DPR','M','LR'].forEach(function(k){U[k]=gl.getUniformLocation(pr,k)});
  var dpr=1,W=0,H=0;
  function size(){dpr=Math.min(devicePixelRatio||1,innerWidth<700?1.5:1.75);var w=Math.round(innerWidth*dpr),h=Math.round(innerHeight*dpr);if(w!==W||h!==H){W=w;H=h;canvas.width=w;canvas.height=h;gl.viewport(0,0,w,h)}}
  size();addEventListener('resize',size);
  var sc=0,t0=performance.now();
  function frame(now){
    var t=(now-t0)/1000,target=scrollY/innerHeight;
    sc+=(target-sc)*(reduce?1:.06);
    lens.x+=(mouse.x-lens.x)*.16;lens.y+=(mouse.y-lens.y)*.16;lens.r+=(lens.tr-lens.r)*.14;
    if(lensEl){lensEl.style.transform='translate('+lens.x+'px,'+lens.y+'px)'}
    gl.uniform2f(U.R,W,H);gl.uniform1f(U.T,reduce?4:t);gl.uniform1f(U.S,sc);gl.uniform1f(U.DPR,dpr);
    gl.uniform2f(U.M,lens.x*dpr,(innerHeight-lens.y)*dpr);gl.uniform1f(U.LR,lens.r*dpr);
    gl.drawArrays(gl.TRIANGLES,0,3);
    if(!reduce)requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
  if(reduce)addEventListener('scroll',function(){requestAnimationFrame(frame)},{passive:true});
}catch(e){console.warn('texture off',e);gl=null}}

/* ---------- glass lens follows the cursor (desktop) ---------- */
if(gl&&fine&&!reduce){
  addEventListener('pointermove',function(e){mouse.x=e.clientX;mouse.y=e.clientY;if(!lensEl.classList.contains('on')){lensEl.classList.add('on');lens.x=mouse.x;lens.y=mouse.y}
    var over=e.target.closest&&e.target.closest('.card-g,.links,.btn,.pill,input,a,button');
    var big=e.target.closest&&e.target.closest('.hero,.head');
    lens.tr=over&&!big?0:(big?110:75);lensEl.classList.toggle('big',!!big&&!over);lensEl.style.opacity=over&&!big?0:'';
  },{passive:true});
  d.addEventListener('mouseleave',function(){lensEl.classList.remove('on');lens.tr=0});
}

/* ---------- glass card light follows pointer ---------- */
$$('.card-g').forEach(function(c){c.addEventListener('pointermove',function(e){var r=c.getBoundingClientRect();c.style.setProperty('--x',(e.clientX-r.left)+'px');c.style.setProperty('--y',(e.clientY-r.top)+'px')})});

/* ---------- nav ---------- */
var nav=$('#nav'),burger=$('#burger');
function setMenu(o){nav.classList.toggle('open',o);burger.setAttribute('aria-expanded',o);burger.setAttribute('aria-label',o?'Close menu':'Open menu')}
burger.addEventListener('click',function(){setMenu(!nav.classList.contains('open'))});
$$('#links a').forEach(function(a){a.addEventListener('click',function(){setMenu(false)})});
d.addEventListener('keydown',function(e){if(e.key==='Escape')setMenu(false)});

/* ---------- split headings into words ---------- */
$$('[data-split]').forEach(function(el){var words=el.textContent.trim().split(/\s+/);el.setAttribute('aria-label',el.textContent.trim());
  el.innerHTML=words.map(function(w,i){return '<span class="w" aria-hidden="true"><span style="--i:'+i+'">'+w.replace(/&/g,'&amp;').replace(/</g,'&lt;')+'</span></span>'}).join(' ')});

/* ---------- reveals ---------- */
var groups=new Map();
$$('[data-in]').forEach(function(el){var p=el.parentNode,k=groups.get(p)||0;el.style.setProperty('--d',(k*110)+'ms');groups.set(p,k+1)});
var all=$$('[data-in],[data-split]');
if('IntersectionObserver' in window){
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add(e.target.hasAttribute('data-split')?'split-in':'in');io.unobserve(e.target)}})},{threshold:.15});
  all.forEach(function(el){io.observe(el)});
}else all.forEach(function(el){el.classList.add('in','split-in')});

/* ---------- nav backdrop ---------- */
addEventListener('scroll',function(){nav.classList.toggle('solid',scrollY>40)},{passive:true});

/* ---------- active nav link ---------- */
var secs=['about','work','skills'].map(function(id){return d.getElementById(id)}),la=$$('#links a');
addEventListener('scroll',function(){var mid=innerHeight*.4,cur=-1;secs.forEach(function(s,i){var r=s.getBoundingClientRect();if(r.top<mid&&r.bottom>mid)cur=i});la.forEach(function(a,i){a.classList.toggle('cur',i===cur)})},{passive:true});

/* ---------- PingBoard live status ---------- */
function setRow(el,m){if(!el)return;var s=el.querySelector('span');if(!m){el.className='';s.textContent='see live page';return}
  var up=/up|ok|operational|online/i.test(String(m.status));el.className=up?'up':'down';var u=m.uptime_24h;
  s.textContent=(up?'Up':'Down')+(u!=null?' · '+(Math.round(u*10)/10)+'% today':'')}
function find(l,w){return l.filter(function(m){return String(m.name||'').toLowerCase().indexOf(w)>-1})[0]}
fetch('https://pingboard-backend.onrender.com/api/public/status/mohanraj/').then(function(r){if(!r.ok)throw 0;return r.json()}).then(function(j){var l=j.monitors||[];setRow($('#s-shop'),find(l,'shop'));setRow($('#s-ping'),find(l,'ping'))}).catch(function(){setRow($('#s-shop'));setRow($('#s-ping'))});

/* ---------- ShopFlow race ---------- */
var btn=$('#race-btn'),msg=$('#race-msg'),stock=$('#stock'),buyers=$$('.buyer'),ran=false;
function reset(){ran=false;stock.textContent='1';msg.textContent='Try it: both buyers press Buy together.';btn.textContent='Both press Buy';buyers.forEach(function(b){b.className='buyer';b.querySelector('em').textContent='waiting'})}
btn.addEventListener('click',function(){
  if(ran){reset();return}ran=true;btn.disabled=true;
  buyers.forEach(function(b){b.querySelector('em').textContent='buying…'});msg.textContent='Two orders arrive in the same moment…';
  setTimeout(function(){var w=Math.random()<.5?0:1,l=1-w;
    buyers[w].classList.add('won');buyers[w].querySelector('em').textContent='got it';
    buyers[l].classList.add('lost');buyers[l].querySelector('em').textContent='sold out';stock.textContent='0';
    msg.textContent='Buyer '+'AB'[w]+' locked the stock first. Buyer '+'AB'[l]+' was told it sold out, and nobody was charged by mistake.';
    btn.textContent='Run it again';btn.disabled=false},reduce?0:900)});

/* ---------- copy email ---------- */
var toast=$('#toast'),tt;
function say(t){toast.textContent=t;toast.classList.add('on');clearTimeout(tt);tt=setTimeout(function(){toast.classList.remove('on')},1800)}
$('#copy').addEventListener('click',function(){var m='mohanrajtunes@gmail.com';(navigator.clipboard?navigator.clipboard.writeText(m):Promise.reject()).then(function(){say('Email copied')}).catch(function(){say(m)})});
})();
