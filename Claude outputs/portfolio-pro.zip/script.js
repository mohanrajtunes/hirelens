(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var fine = window.matchMedia('(pointer: fine)').matches;
  var EMAIL = 'mohanrajtunes@gmail.com';
  var STATUS_URL = 'https://pingboard-backend.onrender.com/api/public/status/mohanraj/';
  document.documentElement.classList.add('js');

  /* toast */
  var toast = $('#toast'), tT;
  function say(m) { toast.textContent = m; toast.classList.add('on'); clearTimeout(tT); tT = setTimeout(function () { toast.classList.remove('on'); }, 2000); }

  /* mobile menu */
  var nav = $('#nav'), burger = $('#burger');
  function menu(open) { nav.classList.toggle('open', open); burger.setAttribute('aria-expanded', open); burger.setAttribute('aria-label', open ? 'Close menu' : 'Open menu'); }
  burger.addEventListener('click', function () { menu(!nav.classList.contains('open')); });
  $$('#links a').forEach(function (a) { a.addEventListener('click', function () { menu(false); }); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') menu(false); });

  /* scroll progress + active link */
  var bar = $('#progress'), secs = $$('main section[id]'), linkFor = {};
  $$('#links a[href^="#"]').forEach(function (a) { linkFor[a.getAttribute('href').slice(1)] = a; });
  function onScroll() {
    var h = document.documentElement.scrollHeight - window.innerHeight;
    bar.style.transform = 'scaleX(' + (h > 0 ? window.scrollY / h : 0) + ')';
    var cur = null;
    secs.forEach(function (s) { if (s.getBoundingClientRect().top < window.innerHeight * 0.4) cur = s.id; });
    Object.keys(linkFor).forEach(function (k) { linkFor[k].classList.toggle('on', k === cur); });
  }
  window.addEventListener('scroll', onScroll, { passive: true }); onScroll();

  /* entrances, staggered inside each group */
  var items = $$('[data-in]');
  if ('IntersectionObserver' in window && !reduce) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); if (e.target.querySelector && e.target.querySelector('[data-count]')) counts(e.target); } });
    }, { threshold: 0.14, rootMargin: '0px 0px -6% 0px' });
    var groups = new Map();
    items.forEach(function (el) { var p = el.parentNode, n = groups.get(p) || 0; el.style.setProperty('--d', Math.min(n, 6) * 90 + 'ms'); groups.set(p, n + 1); io.observe(el); });
  } else { items.forEach(function (el) { el.classList.add('in'); }); counts(document); }

  /* numbers count up */
  function counts(root) {
    $$('[data-count]', root).forEach(function (b) {
      if (b.dataset.done) return; b.dataset.done = 1;
      var to = +b.dataset.count, suf = b.dataset.suffix || '', t0 = null, from = to > 1000 ? to - 40 : 0;
      if (reduce) { b.textContent = to + suf; return; }
      (function step(t) { if (!t0) t0 = t; var p = Math.min(1, (t - t0) / 1400), e = 1 - Math.pow(1 - p, 3); b.textContent = Math.round(from + (to - from) * e) + suf; if (p < 1) requestAnimationFrame(step); })(performance.now());
    });
  }

  /* the name: letters rise in, and lean away from the mouse */
  var name = $('#name');
  if (!reduce) {
    var text = name.textContent; name.textContent = ''; name.setAttribute('aria-label', text); name.classList.add('split');
    text.split('').forEach(function (c, i) {
      var s = document.createElement('span'); s.className = 'ch'; s.setAttribute('aria-hidden', 'true'); s.textContent = c === ' ' ? ' ' : c; s.style.setProperty('--i', i);
      s.animate([{ transform: 'translateY(70%) rotate(8deg)', opacity: 0 }, { transform: 'none', opacity: 1 }], { duration: 800, delay: 250 + i * 55, easing: 'cubic-bezier(.2,1.4,.4,1)', fill: 'backwards' });
      name.appendChild(s);
    });
    if (fine) {
      var chs = $$('.ch', name);
      name.addEventListener('pointermove', function (e) {
        chs.forEach(function (c) { var r = c.getBoundingClientRect(), d = e.clientX - (r.left + r.width / 2), f = Math.max(0, 1 - Math.abs(d) / 220); c.style.transform = 'translateY(' + (-18 * f) + 'px) rotate(' + (d > 0 ? -1 : 1) * 6 * f + 'deg)'; c.style.transition = 'transform .15s'; });
      });
      name.addEventListener('pointerleave', function () { chs.forEach(function (c) { c.style.transition = 'transform .6s cubic-bezier(.2,1.6,.4,1)'; c.style.transform = ''; }); });
    }
  }

  /* typed role */
  var swap = $('#swap'), words = ['AI apps', 'full stack products', 'search that cites its sources', 'things that stay online'];
  if (!reduce) {
    var wi = 0, ci = words[0].length, del = true;
    (function type() {
      var w = words[wi]; ci += del ? -1 : 1; swap.textContent = w.slice(0, ci);
      var wait = del ? 34 : 70;
      if (!del && ci === w.length) { del = true; wait = 1900; }
      if (del && ci === 0) { del = false; wi = (wi + 1) % words.length; wait = 260; }
      setTimeout(type, wait);
    })();
  }

  /* marquee */
  var track = $('#track'), sk = ['Python', 'Django', 'Django REST Framework', 'React', 'PostgreSQL', 'RAG', 'AI agents', 'pgvector', 'LLM APIs', 'JavaScript', 'Docker', 'Git'];
  track.innerHTML = sk.concat(sk).map(function (s) { return '<span>' + s + '</span>'; }).join('');

  /* glass cards: light follows the cursor, card tilts in 3D */
  $$('.glass').forEach(function (el) {
    el.addEventListener('pointermove', function (e) {
      var r = el.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
      el.style.setProperty('--mx', x + 'px'); el.style.setProperty('--my', y + 'px');
      if (fine && !reduce && el.classList.contains('tilt')) {
        var k = el.classList.contains('proj') ? 3 : 6;
        el.style.transform = 'perspective(1000px) rotateX(' + ((y / r.height - .5) * -k) + 'deg) rotateY(' + ((x / r.width - .5) * k) + 'deg) translateY(-4px)';
      }
    });
    el.addEventListener('pointerleave', function () { el.style.transform = ''; });
  });

  /* buttons pull slightly toward the cursor */
  if (fine && !reduce) $$('.btn').forEach(function (b) {
    b.addEventListener('pointermove', function (e) { var r = b.getBoundingClientRect(); b.style.translate = ((e.clientX - r.left - r.width / 2) * .18) + 'px ' + ((e.clientY - r.top - r.height / 2) * .25) + 'px'; });
    b.addEventListener('pointerleave', function () { b.style.translate = ''; });
  });

  /* particle net behind everything */
  var cv = $('#net'), cx = cv.getContext('2d'), W, H, pts = [], mouse = { x: -999, y: -999 };
  function size() {
    var d = Math.min(window.devicePixelRatio || 1, 2); W = window.innerWidth; H = window.innerHeight;
    cv.width = W * d; cv.height = H * d; cx.setTransform(d, 0, 0, d, 0, 0);
    var n = Math.min(90, Math.round(W * H / 16000)); pts = [];
    for (var i = 0; i < n; i++) pts.push({ x: Math.random() * W, y: Math.random() * H, vx: (Math.random() - .5) * .35, vy: (Math.random() - .5) * .35, r: Math.random() * 1.6 + .6, c: i % 3 });
  }
  var COL = ['123,97,255', '45,226,230', '255,181,71'];
  function draw() {
    cx.clearRect(0, 0, W, H);
    for (var i = 0; i < pts.length; i++) {
      var p = pts[i]; p.x += p.vx; p.y += p.vy;
      if (p.x < 0 || p.x > W) p.vx *= -1; if (p.y < 0 || p.y > H) p.vy *= -1;
      var mx = p.x - mouse.x, my = p.y - mouse.y, md = Math.sqrt(mx * mx + my * my);
      if (md < 140) { p.x += mx / md * 1.2; p.y += my / md * 1.2; }
      cx.fillStyle = 'rgba(' + COL[p.c] + ',.9)'; cx.beginPath(); cx.arc(p.x, p.y, p.r, 0, 6.28); cx.fill();
      for (var j = i + 1; j < pts.length; j++) {
        var q = pts[j], dx = p.x - q.x, dy = p.y - q.y, dd = dx * dx + dy * dy;
        if (dd < 17000) { cx.strokeStyle = 'rgba(' + COL[p.c] + ',' + (.22 * (1 - dd / 17000)) + ')'; cx.lineWidth = 1; cx.beginPath(); cx.moveTo(p.x, p.y); cx.lineTo(q.x, q.y); cx.stroke(); }
      }
    }
  }
  size(); window.addEventListener('resize', size);
  if (reduce) draw(); else { (function loop() { if (!document.hidden) draw(); requestAnimationFrame(loop); })(); window.addEventListener('pointermove', function (e) { mouse.x = e.clientX; mouse.y = e.clientY; }, { passive: true }); }

  /* live status from PingBoard */
  var rows = [{ el: $('#s-shop'), key: 'shop' }, { el: $('#s-ping'), key: 'ping' }];
  function setRow(r, st, up) { r.el.className = st || ''; $('span', r.el).textContent = up == null ? (st === 'live' ? 'online' : 'checking…') : (st === 'down' ? 'down · ' : 'up · ') + (up >= 99.995 ? '100' : up.toFixed(1)) + '% today'; }
  function load() {
    fetch(STATUS_URL, { headers: { Accept: 'application/json' } }).then(function (r) { if (!r.ok) throw 0; return r.json(); }).then(function (d) {
      var seen = 0; (d.monitors || []).forEach(function (m) { var n = (m.name || '').toLowerCase(); rows.forEach(function (r) { if (n.indexOf(r.key) !== -1) { setRow(r, m.status, typeof m.uptime_24h === 'number' ? m.uptime_24h : null); seen++; } }); });
      if (!seen) throw 0;
    }).catch(function () { rows.forEach(function (r) { if (!/up|down/.test(r.el.className)) setRow(r, 'live', null); }); });
  }
  load(); setInterval(function () { if (!document.hidden) load(); }, 120000);

  /* ShopFlow demo */
  var rb = $('#race-btn'), rm = $('#race-msg'), stock = $('#stock'), buyers = $$('#race .buyer');
  rb.addEventListener('click', function () {
    if (rb.dataset.done) { delete rb.dataset.done; rb.textContent = 'Both press Buy'; stock.textContent = '1'; buyers.forEach(function (b) { b.className = 'buyer'; $('span', b).textContent = 'waiting'; }); rm.textContent = 'Both press Buy at the same time. Only one should win.'; return; }
    rb.disabled = true; buyers.forEach(function (b) { $('span', b).textContent = 'buying…'; });
    rm.textContent = 'Buyer A reaches the stock first and locks it. Buyer B has to wait…';
    setTimeout(function () {
      buyers[0].classList.add('won'); $('span', buyers[0]).textContent = 'paid ✓'; buyers[1].classList.add('lost'); $('span', buyers[1]).textContent = 'sold out';
      stock.textContent = '0'; rm.textContent = 'B checks the stock after A is done: none left, so B is told it sold out. One item, one sale.';
      rb.disabled = false; rb.textContent = 'Reset'; rb.dataset.done = 1;
    }, 1200);
  });

  /* copy email */
  $('#copy').addEventListener('click', function () {
    var ok = function () { say('Email copied'); };
    if (navigator.clipboard) navigator.clipboard.writeText(EMAIL).then(ok, function () { say(EMAIL); }); else say(EMAIL);
  });
})();
