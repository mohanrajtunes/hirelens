(function(){
var d=document,root=d.documentElement;root.classList.add('js');
var $=function(s){return d.querySelector(s)},$$=function(s){return [].slice.call(d.querySelectorAll(s))};
var reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;

/* ---------- live poster texture (WebGL) ---------- */
var posters=$$('.poster');
function hex(h){h=h.trim().replace('#','');return [parseInt(h.slice(0,2),16)/255,parseInt(h.slice(2,4),16)/255,parseInt(h.slice(4,6),16)/255]}
function params(el){var c=el.dataset.c.split(',').map(hex),p=el.dataset.p.split(',').map(Number);return {c1:c[0],c2:c[1],c3:c[2],den:p[0],ang:p[1],warp:p[2],fold:p[3],half:p[4],lens:p[5]}}
var P=posters.map(params);
var cur=JSON.parse(JSON.stringify(P[0]));
var canvas=$('#bg'),gl=null;
try{gl=canvas.getContext('webgl',{antialias:false,alpha:false,powerPreference:'high-performance'})}catch(e){}
if(gl){
  var vs='attribute vec2 a;void main(){gl_Position=vec4(a,0.,1.);}';
  var fs=[
  'precision highp float;',
  'uniform vec2 R;uniform float T,DPR;uniform vec3 C1,C2,C3;uniform float DEN,ANG,WARP,FOLD,HALF,LENS;uniform vec2 M;uniform float LR;',
  'float h(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}',
  'float n(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h(i),h(i+vec2(1,0)),f.x),mix(h(i+vec2(0,1)),h(i+vec2(1,1)),f.x),f.y);}',
  'float fbm(vec2 p){float v=0.,a=.5;for(int i=0;i<4;i++){v+=a*n(p);p=p*2.03+vec2(1.7,9.2);a*=.5;}return v;}',
  'vec3 pat(vec2 p){',
  ' float c=cos(ANG),s=sin(ANG);p=mat2(c,-s,s,c)*p;',
  ' float f=fbm(p*1.1+vec2(T*.03,-T*.02));',
  ' float w=p.x*DEN+sin(p.y*2.1+T*.32)*1.6*WARP+f*5.*WARP;',
  ' float r=sin(w);',
  ' float sh=pow(.5+.5*r,FOLD);',
  ' float big=smoothstep(.15,.9,fbm(p*.45+vec2(-T*.015,T*.01)));',
  ' vec3 col=mix(C1,C2,mix(sh,1.,.18)*(.72+.38*big));',
  ' col=mix(col,C3,pow(max(r,0.),14.)*(.35+.65*big));',
  ' col+=C3*.12*cos(w*.5+1.3)*big;',
  ' return col;}',
  'void main(){',
  ' vec2 uv=gl_FragCoord.xy/R.y; vec2 m=M/R.y; float lr=LR/R.y;',
  ' float dl=length(uv-m); float inside=LENS*smoothstep(lr,lr-.004,dl);',
  ' vec2 q=mix(uv,m+(uv-m)*.34,inside);',
  ' vec3 col=pat(q-vec2(.9,.5));',
  ' if(inside>.0){vec3 cr=pat(m+(uv-m)*.345-vec2(.9,.5));col=mix(col,vec3(cr.r,col.g,col.b),inside*.7);}',
  ' float rim=LENS*(smoothstep(lr-.014,lr,dl)-smoothstep(lr,lr+.002,dl));',
  ' col+=rim*.55;',
  ' col*=1.-LENS*.4*smoothstep(lr+.07,lr,dl)*step(lr,dl);',
  ' float lum=dot(col,vec3(.3,.59,.11));',
  ' vec2 g=gl_FragCoord.xy/(6.5*DPR); float dd=length(fract(g)-.5);',
  ' float rad=.62*sqrt(clamp(lum*1.25,0.,1.));',
  ' float dots=smoothstep(rad+.06,rad-.06,dd);',
  ' vec3 hc=mix(C1*.35,min(col*1.35,1.),dots);',
  ' float hm=HALF*smoothstep(.25,.95,gl_FragCoord.x/R.x)*(.55+.45*smoothstep(0.,.7,gl_FragCoord.y/R.y));',
  ' col=mix(col,hc,hm);',
  ' vec2 v=gl_FragCoord.xy/R-.5; col*=1.-.4*dot(v,v);',
  ' col+=(h(gl_FragCoord.xy+fract(T)*61.)-.5)*.07;',
  ' gl_FragColor=vec4(col,1.);}'
  ].join('\n');
  function sh(t,s){var o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);if(!gl.getShaderParameter(o,gl.COMPILE_STATUS))throw gl.getShaderInfoLog(o);return o}
  try{
    var pr=gl.createProgram();gl.attachShader(pr,sh(gl.VERTEX_SHADER,vs));gl.attachShader(pr,sh(gl.FRAGMENT_SHADER,fs));gl.linkProgram(pr);gl.useProgram(pr);
    var b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),gl.STATIC_DRAW);
    var al=gl.getAttribLocation(pr,'a');gl.enableVertexAttribArray(al);gl.vertexAttribPointer(al,2,gl.FLOAT,false,0,0);
    var U={};['R','T','DPR','C1','C2','C3','DEN','ANG','WARP','FOLD','HALF','LENS','M','LR'].forEach(function(k){U[k]=gl.getUniformLocation(pr,k)});
    var dpr=1,W=0,H=0;
    function size(){dpr=Math.min(devicePixelRatio||1,innerWidth<700?1.25:1.5);var w=Math.round(innerWidth*dpr),h=Math.round(innerHeight*dpr);if(w!==W||h!==H){W=w;H=h;canvas.width=w;canvas.height=h;gl.viewport(0,0,w,h)}}
    size();addEventListener('resize',size);
    var touch=!matchMedia('(pointer:fine)').matches;
    var mouse={x:innerWidth*.62,y:innerHeight*.45},lens={x:mouse.x,y:mouse.y};
    addEventListener('pointermove',function(e){if(e.pointerType==='mouse'){mouse.x=e.clientX;mouse.y=e.clientY}},{passive:true});
    var active=0;
    function pick(){var mid=innerHeight/2,best=0,bd=1e9;posters.forEach(function(p,i){var r=p.getBoundingClientRect(),c=Math.abs((r.top+r.bottom)/2-mid);if(r.top<=mid&&r.bottom>=mid){best=i;bd=-1}else if(bd>=0&&c<bd){bd=c;best=i}});active=best}
    addEventListener('scroll',pick,{passive:true});pick();
    function lerp(a,b,k){return a+(b-a)*k}
    var t0=performance.now(),last=0;
    function frame(now){
      var t=(now-t0)/1000,tg=P[active],k=reduce?1:.07;
      ['den','ang','warp','fold','half','lens'].forEach(function(f){cur[f]=lerp(cur[f],tg[f],k)});
      ['c1','c2','c3'].forEach(function(f){for(var i=0;i<3;i++)cur[f][i]=lerp(cur[f][i],tg[f][i],k)});
      if(touch){mouse.x=innerWidth*(.55+.25*Math.cos(t*.4));mouse.y=innerHeight*(.4+.18*Math.sin(t*.55))}
      lens.x=lerp(lens.x,mouse.x,.12);lens.y=lerp(lens.y,mouse.y,.12);
      gl.uniform2f(U.R,W,H);gl.uniform1f(U.T,reduce?8:t);gl.uniform1f(U.DPR,dpr);
      gl.uniform3fv(U.C1,cur.c1);gl.uniform3fv(U.C2,cur.c2);gl.uniform3fv(U.C3,cur.c3);
      gl.uniform1f(U.DEN,cur.den);gl.uniform1f(U.ANG,cur.ang);gl.uniform1f(U.WARP,cur.warp);gl.uniform1f(U.FOLD,cur.fold);gl.uniform1f(U.HALF,cur.half);gl.uniform1f(U.LENS,cur.lens);
      gl.uniform2f(U.M,lens.x*dpr,(innerHeight-lens.y)*dpr);gl.uniform1f(U.LR,Math.min(innerWidth,innerHeight)*(touch?.2:.16)*dpr);
      gl.drawArrays(gl.TRIANGLES,0,3);
      if(!reduce||Math.abs(cur.den-tg.den)>.01)requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
    if(reduce)addEventListener('scroll',function(){requestAnimationFrame(frame)},{passive:true});
  }catch(e){console.warn('texture off',e)}
}

/* ---------- nav ---------- */
var nav=$('#nav'),burger=$('#burger');
function setMenu(o){nav.classList.toggle('open',o);burger.setAttribute('aria-expanded',o);burger.setAttribute('aria-label',o?'Close menu':'Open menu')}
burger.addEventListener('click',function(){setMenu(!nav.classList.contains('open'))});
$$('#links a').forEach(function(a){a.addEventListener('click',function(){setMenu(false)})});
d.addEventListener('keydown',function(e){if(e.key==='Escape')setMenu(false)});

/* ---------- reveals ---------- */
$$('.name span,.num,.serif,.big-v').forEach(function(el,i){el.classList.add('rise');el.style.transitionDelay=((i%2)*120)+'ms'});
var targets=$$('[data-in],.rise');
if('IntersectionObserver' in window){
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:.12});
  $$('.tools [data-in]').forEach(function(el,i){el.style.setProperty('--d',(i*90)+'ms')});
  targets.forEach(function(el){io.observe(el)});
}else targets.forEach(function(el){el.classList.add('in')});

/* ---------- PingBoard live status ---------- */
function setRow(el,m){if(!el)return;var s=el.querySelector('span');if(!m){el.className='';s.textContent='see live page';return}
  var up=/up|ok|operational|online/i.test(String(m.status));el.className=up?'up':'down';var u=m.uptime_24h;
  s.textContent=(up?'Up':'Down')+(u!=null?' · '+(Math.round(u*10)/10)+'% today':'')}
function find(l,w){return l.filter(function(m){return String(m.name||'').toLowerCase().indexOf(w)>-1})[0]}
fetch('https://pingboard-backend.onrender.com/api/public/status/mohanraj/').then(function(r){if(!r.ok)throw 0;return r.json()}).then(function(j){var l=j.monitors||[];setRow($('#s-shop'),find(l,'shop'));setRow($('#s-ping'),find(l,'ping'))}).catch(function(){setRow($('#s-shop'));setRow($('#s-ping'))});

/* ---------- ShopFlow race ---------- */
var btn=$('#race-btn'),msg=$('#race-msg'),stock=$('#stock'),buyers=$$('.buyer'),ran=false;
function reset(){ran=false;stock.textContent='1';msg.textContent='Both press Buy at the same time.';btn.textContent='Both press Buy';buyers.forEach(function(b){b.className='buyer';b.querySelector('span').textContent='waiting'})}
btn.addEventListener('click',function(){
  if(ran){reset();return}ran=true;btn.disabled=true;
  buyers.forEach(function(b){b.querySelector('span').textContent='pressing Buy…'});msg.textContent='Two orders arrive in the same moment…';
  setTimeout(function(){var w=Math.random()<.5?0:1,l=1-w;
    buyers[w].classList.add('won');buyers[w].querySelector('span').textContent='order placed';
    buyers[l].classList.add('lost');buyers[l].querySelector('span').textContent='sold out';stock.textContent='0';
    msg.textContent='Buyer '+'AB'[w]+' locked the stock first and got it. Buyer '+'AB'[l]+' was told it sold out, and nobody was charged by mistake.';
    btn.textContent='Run it again';btn.disabled=false},reduce?0:900)});

/* ---------- copy email ---------- */
var toast=$('#toast'),tt;
function say(t){toast.textContent=t;toast.classList.add('on');clearTimeout(tt);tt=setTimeout(function(){toast.classList.remove('on')},1800)}
$('#copy').addEventListener('click',function(){var m='mohanrajtunes@gmail.com';(navigator.clipboard?navigator.clipboard.writeText(m):Promise.reject()).then(function(){say('Email copied')}).catch(function(){say(m)})});
})();
