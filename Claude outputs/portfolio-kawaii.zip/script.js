(function () {
  'use strict';

  var STATUS_URL = 'https://pingboard-backend.onrender.com/api/public/status/mohanraj/';
  var EMAIL = 'mohanrajtunes@gmail.com';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var root = document.documentElement;
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var finePointer = window.matchMedia('(pointer: fine)').matches;
  var PASTELS = ['#FF7EB6', '#B79CFF', '#7EE0C3', '#FFE37A', '#8FD3FF', '#FFA45C'];

  /* ---------- toast ---------- */
  var toastEl = $('#toast'), toastT;
  function say(m) { toastEl.textContent = m; toastEl.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(function () { toastEl.classList.remove('on'); }, 2000); }

  /* ---------- day / night ---------- */
  $('#theme').addEventListener('click', function () {
    var t = root.dataset.theme === 'night' ? 'day' : 'night';
    root.dataset.theme = t;
    try { localStorage.setItem('mr-theme', t); } catch (e) {}
    say(t === 'night' ? 'Good night ☾ the stars are out' : 'Good morning ☀ candy skies');
  });

  /* ---------- sky: stars at night, sparkles by day ---------- */
  var cv = $('#sky'), cx = cv.getContext('2d'), W, H, dots = [], shoot = null;
  function sizeSky() {
    var d = Math.min(window.devicePixelRatio || 1, 2);
    W = window.innerWidth; H = window.innerHeight;
    cv.width = W * d; cv.height = H * d; cx.setTransform(d, 0, 0, d, 0, 0);
    dots = [];
    var n = Math.round(W * H / 9000);
    for (var i = 0; i < n; i++) dots.push({ x: Math.random() * W, y: Math.random() * H, r: Math.random() * 1.6 + .4, p: Math.random() * 6.28, s: Math.random() * .02 + .005, c: PASTELS[i % PASTELS.length], v: Math.random() * .25 + .05 });
  }
  function star4(x, y, r) {
    cx.beginPath();
    cx.moveTo(x, y - r * 2.2); cx.quadraticCurveTo(x, y, x + r * 2.2, y); cx.quadraticCurveTo(x, y, x, y + r * 2.2); cx.quadraticCurveTo(x, y, x - r * 2.2, y); cx.quadraticCurveTo(x, y, x, y - r * 2.2);
    cx.fill();
  }
  function drawSky() {
    var night = root.dataset.theme === 'night';
    cx.clearRect(0, 0, W, H);
    for (var i = 0; i < dots.length; i++) {
      var d = dots[i];
      d.p += d.s;
      var a = .35 + .65 * Math.abs(Math.sin(d.p));
      if (night) {
        cx.globalAlpha = a; cx.fillStyle = i % 5 ? '#FFF6E0' : d.c;
        if (i % 9 === 0) star4(d.x, d.y, d.r + .6); else { cx.beginPath(); cx.arc(d.x, d.y, d.r, 0, 6.28); cx.fill(); }
      } else if (i % 3 === 0) {
        d.y -= d.v; if (d.y < -10) { d.y = H + 10; d.x = Math.random() * W; }
        cx.globalAlpha = a * .8; cx.fillStyle = i % 2 ? '#FFFFFF' : d.c; star4(d.x, d.y, d.r + .4);
      }
    }
    if (night) {
      if (!shoot && Math.random() < .004) shoot = { x: Math.random() * W * .6 + W * .2, y: Math.random() * H * .3, t: 0 };
      if (shoot) {
        shoot.t += 1;
        var sx = shoot.x + shoot.t * 9, sy = shoot.y + shoot.t * 4;
        var g = cx.createLinearGradient(sx, sy, sx - 90, sy - 40);
        g.addColorStop(0, 'rgba(255,246,224,.9)'); g.addColorStop(1, 'rgba(255,246,224,0)');
        cx.globalAlpha = 1; cx.strokeStyle = g; cx.lineWidth = 2; cx.beginPath(); cx.moveTo(sx, sy); cx.lineTo(sx - 90, sy - 40); cx.stroke();
        if (shoot.t > 40) shoot = null;
      }
    }
    cx.globalAlpha = 1;
  }
  function skyLoop() { if (!document.hidden) drawSky(); requestAnimationFrame(skyLoop); }
  sizeSky();
  if (reduce) drawSky(); else requestAnimationFrame(skyLoop);

  /* ---------- Mochi visits the About section too ---------- */
  var m = $('.hero-art .mochi');
  if (m) $('#about-mochi').appendChild(m.cloneNode(true));

  /* ---------- Nyan animation (lottie) ---------- */
  var nyanText = null, nyanWaiters = [];
  function withNyan(cb) {
    if (nyanText) return cb(JSON.parse(nyanText));
    nyanWaiters.push(cb);
    if (nyanWaiters.length > 1) return;
    fetch('nyan.json').then(function (r) { return r.text(); }).then(function (t) {
      nyanText = t;
      nyanWaiters.splice(0).forEach(function (f) { f(JSON.parse(t)); });
    }).catch(function () {});
  }
  function playNyan(box, speed) {
    if (!window.lottie) return null;
    var anim = null;
    withNyan(function (data) {
      anim = window.lottie.loadAnimation({ container: box, renderer: 'svg', loop: true, autoplay: !reduce, animationData: data });
      if (speed) anim.setSpeed(speed);
    });
    return { destroy: function () { if (anim) anim.destroy(); } };
  }

  /* ---------- the rainbow ride ---------- */
  var ride = $('#work'), svg = $('#rainbow'), pathEl = $('#ride-path'), stripes = $$('#stripes .st');
  var rider = $('#rider'), stops = $$('.stop');
  var samples = [], total = 0, cur = { x: 0, y: 0 }, target = { x: 0, y: 0, len: 0 }, faceLeft = false;

  function smooth(pts) { // Catmull-Rom through the points, as cubic beziers
    var d = 'M' + pts[0].x + ',' + pts[0].y;
    for (var i = 0; i < pts.length - 1; i++) {
      var p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
      d += ' C' + (p1.x + (p2.x - p0.x) / 6) + ',' + (p1.y + (p2.y - p0.y) / 6) + ' ' + (p2.x - (p3.x - p1.x) / 6) + ',' + (p2.y - (p3.y - p1.y) / 6) + ' ' + p2.x + ',' + p2.y;
    }
    return d;
  }
  function buildPath() {
    var box = ride.getBoundingClientRect(), w = box.width, h = box.height, top = box.top;
    var narrow = w < 820;
    svg.setAttribute('viewBox', '0 0 ' + w + ' ' + h);
    var title = $('.sec-title', ride).getBoundingClientRect();
    var pts = [{ x: w / 2, y: title.bottom - top + 70 }];
    stops.forEach(function (s, i) {
      var pr = $('.planet-wrap', s).getBoundingClientRect();
      var c = { x: pr.left - box.left + pr.width / 2, y: pr.top - top + pr.height / 2 };
      if (narrow && i > 0) pts.push({ x: i % 2 ? w * .14 : w * .86, y: (pts[pts.length - 1].y + c.y) / 2 });
      pts.push(c);
    });
    pts.push({ x: w / 2, y: h - 40 });
    var d = smooth(pts);
    pathEl.setAttribute('d', d);
    stripes.forEach(function (s) { s.setAttribute('d', d); });
    total = pathEl.getTotalLength();
    stripes.forEach(function (s) { s.style.strokeDasharray = total + ' ' + total; });
    samples = [];
    for (var l = 0; l <= total; l += 6) { var p = pathEl.getPointAtLength(l); samples.push({ l: l, x: p.x, y: p.y }); }
    stops.forEach(function (s) { var pr = $('.planet-wrap', s).getBoundingClientRect(); s._y = pr.top - top + pr.height / 2; });
    update(true);
  }
  function lenAtY(y) { // first sample at or below y (the path only goes down)
    var lo = 0, hi = samples.length - 1;
    if (!samples.length) return 0;
    if (y <= samples[0].y) return 0;
    while (lo < hi) { var mid = (lo + hi) >> 1; if (samples[mid].y < y) lo = mid + 1; else hi = mid; }
    return samples[lo].l;
  }
  function update(jump) {
    if (!samples.length) return;
    var box = ride.getBoundingClientRect();
    var y = window.innerHeight * .5 - box.top;
    var len = reduce ? 0 : lenAtY(y);
    var p = pathEl.getPointAtLength(len);
    target.x = p.x; target.y = p.y; target.len = len;
    if (jump) { cur.x = p.x; cur.y = p.y; place(); }
    stripes.forEach(function (s) { s.style.strokeDashoffset = reduce ? 0 : (total - len); });
    stops.forEach(function (s) { if (!s.classList.contains('visited') && (reduce || y > s._y - 30)) visit(s); });
  }
  function place() {
    rider.style.transform = 'translate(' + cur.x + 'px,' + cur.y + 'px)';
    $('.rider-box', rider).style.transform = faceLeft ? 'scaleX(-1)' : '';
  }
  function riderLoop() {
    var dx = target.x - cur.x, dy = target.y - cur.y;
    if (Math.abs(dx) > .3 || Math.abs(dy) > .3) {
      var ahead = pathEl.getPointAtLength(Math.min(total, target.len + 30));
      if (Math.abs(ahead.x - target.x) > 4) faceLeft = ahead.x < target.x;
      cur.x += dx * .14; cur.y += dy * .14;
      place();
    }
    requestAnimationFrame(riderLoop);
  }
  function burst(el, n, chars) {
    if (reduce) return;
    var r = el.getBoundingClientRect();
    for (var i = 0; i < n; i++) {
      var s = document.createElement('span');
      s.className = 'pop';
      s.textContent = chars[i % chars.length];
      s.style.left = (r.left + r.width / 2) + 'px'; s.style.top = (r.top + r.height / 2) + 'px';
      s.style.color = PASTELS[i % PASTELS.length];
      document.body.appendChild(s);
      var a = Math.random() * 6.28, dist = 60 + Math.random() * 90;
      s.animate([{ transform: 'translate(0,0) scale(.4)', opacity: 1 }, { transform: 'translate(' + Math.cos(a) * dist + 'px,' + Math.sin(a) * dist + 'px) scale(1.2) rotate(' + (Math.random() * 180) + 'deg)', opacity: 0 }],
        { duration: 800 + Math.random() * 400, easing: 'cubic-bezier(.2,.8,.2,1)' }).onfinish = (function (x) { return function () { x.remove(); }; })(s);
    }
  }
  function visit(s) {
    s.classList.add('visited');
    burst($('.planet-wrap', s), 12, ['✦', '★', '♥', '✧']);
  }
  rider.addEventListener('click', function () {
    rider.classList.remove('spin'); void rider.offsetWidth; rider.classList.add('spin');
    burst(rider, 10, ['✦', '♪', '♥']);
    say(['nya~', 'wheee!', 'nyan nyan nyan', 'rainbow power ✦'][Math.floor(Math.random() * 4)]);
  });

  var raf = 0;
  window.addEventListener('scroll', function () { if (!raf) raf = requestAnimationFrame(function () { raf = 0; update(); }); }, { passive: true });
  var rt;
  window.addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(function () { sizeSky(); buildPath(); }, 150); });
  function startRide() {
    buildPath();
    playNyan($('.rider-box', rider));
    if (!reduce) requestAnimationFrame(riderLoop);
  }
  if (document.readyState === 'complete') startRide(); else window.addEventListener('load', startRide);
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { setTimeout(buildPath, 50); });

  /* ---------- catch the flying Nyans ---------- */
  var caught = 0;
  try { caught = +localStorage.getItem('mr-nyans') || 0; } catch (e) {}
  var caughtEl = $('#caught b'); caughtEl.textContent = caught;
  function spawnFlyer() {
    if (document.hidden || !window.lottie) return;
    var goRight = Math.random() > .5;
    var f = document.createElement('button');
    f.className = 'flyer'; f.type = 'button'; f.setAttribute('aria-label', 'A flying Nyan. Click to catch it');
    f.innerHTML = '<span></span>';
    f.style.top = (12 + Math.random() * 62) + 'vh';
    $('#flyers').appendChild(f);
    var player = playNyan($('span', f), 1.4);
    var from = goRight ? -140 : window.innerWidth + 30, to = goRight ? window.innerWidth + 30 : -140;
    var flip = goRight ? '' : ' scaleX(-1)';
    var anim = f.animate([
      { transform: 'translate(' + from + 'px,0)' + flip },
      { transform: 'translate(' + (from + to) / 2 + 'px,-40px)' + flip },
      { transform: 'translate(' + to + 'px,10px)' + flip }
    ], { duration: 5200 + Math.random() * 1500, easing: 'linear' });
    var end = function () { if (player) player.destroy(); f.remove(); };
    anim.onfinish = end;
    f.addEventListener('click', function () {
      caught++;
      try { localStorage.setItem('mr-nyans', caught); } catch (e) {}
      caughtEl.textContent = caught;
      burst(f, 14, ['✦', '★', '+1', '♥']);
      say(caught === 1 ? 'You caught a Nyan! ✦' : caught % 10 === 0 ? caught + ' Nyans! You are a legend ✦' : 'Caught! That makes ' + caught);
      anim.cancel(); end();
    });
  }
  if (!reduce) {
    setTimeout(function loop() { spawnFlyer(); setTimeout(loop, 11000 + Math.random() * 9000); }, 6000);
  }

  /* ---------- sparkle trail behind the cursor ---------- */
  if (finePointer && !reduce) {
    var last = 0;
    window.addEventListener('pointermove', function (e) {
      var now = performance.now(); if (now - last < 45) return; last = now;
      var s = document.createElement('span');
      s.className = 'trail'; s.textContent = Math.random() > .5 ? '✦' : '✧';
      s.style.left = e.clientX + 'px'; s.style.top = e.clientY + 'px'; s.style.color = PASTELS[Math.floor(Math.random() * PASTELS.length)];
      document.body.appendChild(s);
      s.animate([{ transform: 'translateY(0) scale(1)', opacity: 1 }, { transform: 'translateY(18px) scale(.3)', opacity: 0 }], { duration: 700, easing: 'ease-out' }).onfinish = function () { s.remove(); };
    }, { passive: true });
  }

  /* ---------- live status from PingBoard ---------- */
  var rows = [{ el: $('#s-shop'), key: 'shop' }, { el: $('#s-ping'), key: 'ping' }];
  function setRow(r, state, up) {
    r.el.className = 'srow ' + (state || '');
    $('span', r.el).textContent = up == null ? (state === 'live' ? 'deployed' : 'checking…') : (state === 'up' ? 'up · ' : state === 'down' ? 'down · ' : '') + (up >= 99.995 ? '100' : up.toFixed(1)) + '% today';
  }
  function loadStatus() {
    fetch(STATUS_URL, { headers: { Accept: 'application/json' } })
      .then(function (r) { if (!r.ok) throw new Error(); return r.json(); })
      .then(function (data) {
        var seen = 0;
        (data.monitors || []).forEach(function (mo) {
          var n = (mo.name || '').toLowerCase();
          rows.forEach(function (r) { if (n.indexOf(r.key) !== -1) { setRow(r, mo.status, typeof mo.uptime_24h === 'number' ? mo.uptime_24h : null); seen++; } });
        });
        if (!seen) throw new Error();
      })
      .catch(function () { rows.forEach(function (r) { if (!/up|down/.test(r.el.className)) setRow(r, 'live', null); }); });
  }
  loadStatus();
  setInterval(function () { if (!document.hidden) loadStatus(); }, 120000);

  /* ---------- demo: PingBoard ---------- */
  (function () {
    var box = $('#demo-ping'); if (!box) return;
    var siteUp = true, fails = 0, incident = false;
    var mon = $('.mon', box), state = $('.mon-state', box), list = $('.checks', box), msg = $('.demo-msg', box), tbtn = $('[data-act="toggle"]', box);
    tbtn.addEventListener('click', function () {
      siteUp = !siteUp;
      tbtn.textContent = siteUp ? 'Take the site down' : 'Bring the site back';
      msg.textContent = siteUp ? 'The site is back. The next check will see it.' : 'The site is down. PingBoard has not noticed yet: run a check.';
    });
    $('[data-act="check"]', box).addEventListener('click', function () {
      var li = document.createElement('li');
      if (siteUp) {
        fails = 0;
        msg.textContent = incident ? 'Check passed. The incident closes by itself and the owner is told.' : 'Check passed. All good.';
        incident = false;
      } else {
        fails++; li.className = 'fail';
        if (fails === 1) msg.textContent = 'One failed check. Could be a blip, so no alert yet.';
        else if (!incident) { incident = true; msg.textContent = 'Two failures in a row: incident opened, email alert sent.'; }
        else msg.textContent = 'Still down. The incident stays open, no repeat emails.';
      }
      list.appendChild(li);
      while (list.children.length > 14) list.removeChild(list.firstChild);
      li.animate([{ transform: 'scale(0)' }, { transform: 'scale(1.2)' }, { transform: 'scale(1)' }], { duration: 300 });
      mon.classList.toggle('down', !siteUp); mon.classList.toggle('incident', incident);
      state.textContent = incident ? 'Incident' : siteUp ? 'Up' : 'Checking…';
    });
  })();

  /* ---------- demo: ShopFlow ---------- */
  (function () {
    var box = $('#demo-shop'); if (!box) return;
    var btn = $('[data-act="buy"]', box), msg = $('.demo-msg', box), stockEl = $('#stock-n'), lock = $('#lock-on'), buyers = $$('.buyer', box);
    function reset() {
      stockEl.textContent = '1'; stockEl.parentNode.classList.remove('bad');
      buyers.forEach(function (b) { b.classList.remove('won', 'lost'); $('.b-state', b).textContent = 'waiting'; });
    }
    btn.addEventListener('click', function () {
      if (btn.dataset.done) { reset(); btn.textContent = 'Both press Buy'; delete btn.dataset.done; msg.textContent = 'Both buyers press Buy at the same moment.'; return; }
      btn.disabled = true;
      buyers.forEach(function (b) { $('.b-state', b).textContent = 'buying…'; });
      msg.textContent = lock.checked ? 'Buyer A gets the row lock first. Buyer B waits…' : 'No lock: both read "1 in stock" at once…';
      setTimeout(function () {
        if (lock.checked) {
          buyers[0].classList.add('won'); $('.b-state', buyers[0]).textContent = 'paid ✓';
          buyers[1].classList.add('lost'); $('.b-state', buyers[1]).textContent = 'sold out';
          stockEl.textContent = '0';
          msg.textContent = 'With the lock, B reads the stock after A commits: 0 left, so B sees "sold out". One item, one sale.';
        } else {
          buyers.forEach(function (b) { b.classList.add('won'); $('.b-state', b).textContent = 'paid ✓'; });
          stockEl.textContent = '-1'; stockEl.parentNode.classList.add('bad');
          msg.textContent = 'Without the lock, both orders go through and stock hits -1. That is the bug ShopFlow prevents.';
        }
        btn.disabled = false; btn.textContent = 'Reset'; btn.dataset.done = '1';
      }, 1100);
    });
    lock.addEventListener('change', function () { if (btn.dataset.done) btn.click(); });
  })();

  // opening a demo changes the page height: redraw the rainbow
  $$('.try').forEach(function (d) { d.addEventListener('toggle', function () { setTimeout(buildPath, 30); }); });

  /* ---------- copy email ---------- */
  $('#copy').addEventListener('click', function () {
    var ok = function () { say('Email copied ✉ talk soon!'); };
    if (navigator.clipboard) navigator.clipboard.writeText(EMAIL).then(ok, function () { say(EMAIL); }); else say(EMAIL);
  });

  /* ---------- hero entrance ---------- */
  if (!reduce) {
    $$('.hero-text > *').forEach(function (el, i) {
      el.animate([{ opacity: 0, transform: 'translateY(24px)' }, { opacity: 1, transform: 'none' }], { duration: 600, delay: 100 + i * 90, easing: 'cubic-bezier(.3,1.5,.5,1)', fill: 'backwards' });
    });
    var art = $('.hero-art');
    if (art) art.animate([{ opacity: 0, transform: 'scale(.6) rotate(-8deg)' }, { opacity: 1, transform: 'none' }], { duration: 900, delay: 250, easing: 'cubic-bezier(.3,1.6,.5,1)', fill: 'backwards' });
  }
})();
