(function () {
  'use strict';

  var STATUS_URL = 'https://pingboard-backend.onrender.com/api/public/status/mohanraj/';
  var EMAIL = 'mohanrajtunes@gmail.com';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var root = document.documentElement;
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  };

  /* ---------- achievements + XP ---------- */
  var ACH = [
    { id: 'start', ico: '🎮', name: 'Press Start', how: 'Scroll into the quest log' },
    { id: 'spin', ico: '🌀', name: 'OIIA', how: 'Spin Chonk once' },
    { id: 'spin10', ico: '😵‍💫', name: 'Certified Spinner', how: 'Spin Chonk 10 times' },
    { id: 'nyan', ico: '🌈', name: 'Nyan Hunter', how: 'Catch a flying Nyan' },
    { id: 'quests', ico: '🗺️', name: 'Completionist', how: 'Clear all 4 quests' },
    { id: 'grass', ico: '🌱', name: 'Touched Grass', how: 'Try light mode' },
    { id: 'break', ico: '💥', name: 'Broke Something', how: 'Play a mini-game' },
    { id: 'party', ico: '✉️', name: 'Party Invite', how: 'Copy or click my email' },
    { id: 'cheat', ico: '🐈', name: '???', how: 'A secret code', secret: 'Cheat Code: cat rain' }
  ];
  var got = store.get('cb-ach', {});
  var list = $('#achs');
  ACH.forEach(function (a) {
    var li = document.createElement('li');
    li.id = 'ach-' + a.id;
    li.innerHTML = '<span class="ico">' + a.ico + '</span><span><b></b><small></small></span>';
    list.appendChild(li);
  });
  function paintAch() {
    var n = 0;
    ACH.forEach(function (a) {
      var li = $('#ach-' + a.id), has = !!got[a.id];
      if (has) n++;
      li.classList.toggle('got', has);
      $('b', li).textContent = has && a.secret ? a.secret : a.name;
      $('small', li).textContent = a.how;
      $('.ico', li).textContent = has || !a.secret ? a.ico : '🔒';
    });
    $('#ach-count').textContent = n + ' / ' + ACH.length;
    $('#xp-n').textContent = n + ' / ' + ACH.length;
    $('#xp-fill').style.width = (n / ACH.length * 100) + '%';
    $('#lvl').textContent = 'LVL ' + (n + 1);
  }
  var popEl = $('#ach-pop'), popT, queue = [];
  function showNext() {
    if (popEl.classList.contains('on') || !queue.length) return;
    var a = queue.shift();
    popEl.innerHTML = '<span class="ico">' + a.ico + '</span><span><small>ACHIEVEMENT UNLOCKED</small><b>' + (a.secret || a.name) + '</b></span>';
    popEl.classList.add('on');
    clearTimeout(popT);
    popT = setTimeout(function () { popEl.classList.remove('on'); setTimeout(showNext, 450); }, 2600);
  }
  function unlock(id) {
    if (got[id]) return;
    got[id] = 1; store.set('cb-ach', got); paintAch();
    var a = ACH.filter(function (x) { return x.id === id; })[0];
    queue.push(a); showNext();
  }
  paintAch();

  function fx(x, y, text, color) {
    if (reduce) return;
    var s = document.createElement('span');
    s.className = 'fx'; s.textContent = text; s.style.left = x + 'px'; s.style.top = y + 'px'; s.style.color = color || '#FFD43B';
    document.body.appendChild(s);
    var a = Math.random() * 6.28, d = 50 + Math.random() * 80;
    s.animate([{ transform: 'translate(0,0) scale(.5)', opacity: 1 }, { transform: 'translate(' + Math.cos(a) * d + 'px,' + (Math.sin(a) * d - 40) + 'px) scale(1.2)', opacity: 0 }], { duration: 900, easing: 'cubic-bezier(.2,.8,.2,1)' }).onfinish = function () { s.remove(); };
  }
  function burstAt(el, texts, colors) {
    var r = el.getBoundingClientRect();
    for (var i = 0; i < texts.length; i++) fx(r.left + r.width / 2, r.top + r.height / 2, texts[i], colors[i % colors.length]);
  }

  /* ---------- touch grass mode ---------- */
  $('#grass').addEventListener('click', function () {
    var t = root.dataset.theme === 'grass' ? 'night' : 'grass';
    root.dataset.theme = t;
    try { localStorage.setItem('cb-theme', t); } catch (e) {}
    if (t === 'grass') unlock('grass');
  });

  /* ---------- Chonk spins (OIIA) ---------- */
  var chonk = $('#chonk'), oiia = $('#oiia'), spins = store.get('cb-spins', 0), spinT;
  $('#spins').textContent = spins;
  chonk.addEventListener('click', function () {
    spins++; store.set('cb-spins', spins); $('#spins').textContent = spins;
    unlock('spin'); if (spins >= 10) unlock('spin10');
    if (reduce) return;
    chonk.classList.add('spinning');
    oiia.innerHTML = '';
    'OIIA OIIA'.split('').forEach(function (c, i) {
      var sp = document.createElement('span'); sp.textContent = c === ' ' ? ' ' : c; sp.style.animationDelay = (i * 0.07) + 's'; oiia.appendChild(sp);
    });
    burstAt(chonk, ['O', 'I', 'I', 'A', '!!', '✦'], ['#FFD43B', '#3DD6FF', '#FF8A1F', '#FF4D5E']);
    clearTimeout(spinT);
    spinT = setTimeout(function () { chonk.classList.remove('spinning'); oiia.innerHTML = ''; }, 1700);
  });

  /* ---------- quests clear as you reach them ---------- */
  var quests = $$('.quest'), cleared = 0;
  function clearQuest(q) {
    if (q.classList.contains('cleared')) return;
    q.classList.add('cleared');
    $('.q-state', q).textContent = 'CLEARED ✓';
    cleared++;
    burstAt($('h3', q), ['+XP', '✦', '★'], ['#3DD6FF', '#FFD43B', '#FF8A1F']);
    if (cleared === quests.length) unlock('quests');
  }
  if ('IntersectionObserver' in window && !reduce) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) { if (e.isIntersecting) { clearQuest(e.target); io.unobserve(e.target); } });
    }, { threshold: 0.45 });
    quests.forEach(function (q) { io.observe(q); });
    var startIo = new IntersectionObserver(function (es) { if (es[0].isIntersecting) { unlock('start'); startIo.disconnect(); } }, { threshold: 0.1 });
    startIo.observe($('#quests'));
  } else {
    quests.forEach(clearQuest);
  }

  /* ---------- server HP, live from PingBoard ---------- */
  var hp = [{ el: $('#hp-shop'), key: 'shop' }, { el: $('#hp-ping'), key: 'ping' }];
  function setHp(r, state, up) {
    r.el.classList.toggle('down', state === 'down');
    $('b', r.el).style.width = up == null ? (state === 'live' ? '100%' : '0') : Math.max(4, up) + '%';
    $('em', r.el).textContent = up == null ? (state === 'live' ? 'deployed' : 'checking…') : (up >= 99.995 ? '100' : up.toFixed(1)) + '% HP';
  }
  function loadStatus() {
    fetch(STATUS_URL, { headers: { Accept: 'application/json' } })
      .then(function (r) { if (!r.ok) throw new Error(); return r.json(); })
      .then(function (d) {
        var seen = 0;
        (d.monitors || []).forEach(function (m) {
          var n = (m.name || '').toLowerCase();
          hp.forEach(function (r) { if (n.indexOf(r.key) !== -1) { setHp(r, m.status, typeof m.uptime_24h === 'number' ? m.uptime_24h : null); seen++; } });
        });
        if (!seen) throw new Error();
      })
      .catch(function () { hp.forEach(function (r) { if (/checking/.test($('em', r.el).textContent)) setHp(r, 'live', null); }); });
  }
  loadStatus();
  setInterval(function () { if (!document.hidden) loadStatus(); }, 120000);

  /* ---------- mini-game: break a site ---------- */
  (function () {
    var box = $('#demo-ping'); if (!box) return;
    var siteUp = true, fails = 0, incident = false;
    var mon = $('.mon', box), st = $('.mon-state', box), checks = $('.checks', box), msg = $('.mini-msg', box), tb = $('[data-act="toggle"]', box);
    tb.addEventListener('click', function () {
      siteUp = !siteUp; unlock('break');
      tb.textContent = siteUp ? 'take it down' : 'bring it back';
      msg.textContent = siteUp ? 'Back up. The next check will see it.' : 'Site is down. PingBoard has not noticed yet: run a check.';
    });
    $('[data-act="check"]', box).addEventListener('click', function () {
      var li = document.createElement('li');
      unlock('break');
      if (siteUp) { fails = 0; msg.textContent = incident ? 'Check passed. Incident closed by itself, owner told.' : 'Check passed. GG.'; incident = false; }
      else {
        fails++; li.className = 'fail';
        if (fails === 1) msg.textContent = 'One fail. Could be a blip, so no alert yet.';
        else if (!incident) { incident = true; msg.textContent = 'Two fails in a row: INCIDENT OPENED, email sent.'; burstAt(mon, ['!!', '⚠'], ['#FF4D5E']); }
        else msg.textContent = 'Still down. Incident stays open, no spam emails.';
      }
      checks.appendChild(li);
      while (checks.children.length > 16) checks.removeChild(checks.firstChild);
      mon.classList.toggle('down', !siteUp); mon.classList.toggle('incident', incident);
      st.textContent = incident ? 'INCIDENT' : siteUp ? 'UP' : 'CHECKING';
    });
  })();

  /* ---------- mini-game: two buyers ---------- */
  (function () {
    var box = $('#demo-shop'); if (!box) return;
    var btn = $('[data-act="buy"]', box), msg = $('.mini-msg', box), stock = $('#stock-n'), lock = $('#lock-on'), buyers = $$('.buyer', box);
    function reset() { stock.textContent = '1'; stock.parentNode.classList.remove('bad'); buyers.forEach(function (b) { b.classList.remove('won', 'lost'); $('.b-state', b).textContent = 'waiting'; }); }
    btn.addEventListener('click', function () {
      if (btn.dataset.done) { reset(); btn.textContent = 'both press buy'; delete btn.dataset.done; msg.textContent = 'Both press Buy at the same moment.'; return; }
      unlock('break');
      btn.disabled = true;
      buyers.forEach(function (b) { $('.b-state', b).textContent = 'buying…'; });
      msg.textContent = lock.checked ? 'A grabs the row lock. B waits…' : 'No lock: both read "1 in stock"…';
      setTimeout(function () {
        if (lock.checked) {
          buyers[0].classList.add('won'); $('.b-state', buyers[0]).textContent = 'paid ✓';
          buyers[1].classList.add('lost'); $('.b-state', buyers[1]).textContent = 'sold out';
          stock.textContent = '0'; msg.textContent = 'Lock ON: B sees 0 left after A commits. One item, one sale. Boss defeated.';
        } else {
          buyers.forEach(function (b) { b.classList.add('won'); $('.b-state', b).textContent = 'paid ✓'; });
          stock.textContent = '-1'; stock.parentNode.classList.add('bad');
          msg.textContent = 'Lock OFF: both orders go through and stock hits -1. That is the bug ShopFlow prevents.';
          burstAt(stock, ['-1', '💀'], ['#FF4D5E']);
        }
        btn.disabled = false; btn.textContent = 'reset'; btn.dataset.done = '1';
      }, 1100);
    });
    lock.addEventListener('change', function () { if (btn.dataset.done) btn.click(); });
  })();

  /* ---------- lore, typed out like an RPG ---------- */
  var LORE = [
    'Our hero is a Computer Science graduate from Puducherry. He builds things end to end: the API, the database, the interface, the deploy.',
    'He started on the backend with Django. Then he learned AI the hard way: by building an LLM app, then a RAG and agent tool with its own evals.',
    'He cares about the stuff users never see: permissions, stock that can\'t be oversold, and knowing the moment something breaks.',
    'He is looking for a party: an AI engineer or full stack role. He also plays games and listens to music. Mostly music. Okay, also games.'
  ];
  var li = 0, typing = null, sayEl = $('#lore-text');
  function typeLore(i) {
    clearInterval(typing);
    var text = LORE[i], n = 0;
    if (reduce) { sayEl.textContent = text; return; }
    sayEl.textContent = '';
    typing = setInterval(function () { n += 2; sayEl.textContent = text.slice(0, n); if (n >= text.length) clearInterval(typing); }, 22);
  }
  $('#lore-next').addEventListener('click', function () { li = (li + 1) % LORE.length; typeLore(li); $('#lore-next').textContent = li === LORE.length - 1 ? 'restart ↺' : 'next ▶'; });
  if ('IntersectionObserver' in window) {
    var lio = new IntersectionObserver(function (es) { if (es[0].isIntersecting) { typeLore(0); lio.disconnect(); } }, { threshold: 0.5 });
    lio.observe($('.dialog'));
  }

  /* ---------- contact ---------- */
  $('#copy').addEventListener('click', function (e) {
    unlock('party');
    var b = e.currentTarget;
    var ok = function () { b.textContent = 'copied ✓'; setTimeout(function () { b.textContent = 'copy'; }, 1600); };
    if (navigator.clipboard) navigator.clipboard.writeText(EMAIL).then(ok, ok); else ok();
  });
  $('#invite').addEventListener('click', function () { unlock('party'); });

  /* ---------- flying Nyans = coins ---------- */
  var coins = store.get('cb-coins', 0), nyanText = null;
  $('#coins').textContent = coins;
  function nyanData(cb) {
    if (nyanText) return cb(JSON.parse(nyanText));
    fetch('nyan.json').then(function (r) { return r.text(); }).then(function (t) { nyanText = t; cb(JSON.parse(t)); }).catch(function () {});
  }
  function spawnNyan() {
    if (document.hidden || !window.lottie) return;
    nyanData(function (data) {
      var goRight = Math.random() > .5;
      var f = document.createElement('button');
      f.type = 'button'; f.className = 'flyer'; f.setAttribute('aria-label', 'Flying Nyan, click to catch');
      f.innerHTML = '<span></span>';
      f.style.top = (14 + Math.random() * 60) + 'vh';
      $('#flyers').appendChild(f);
      var anim = window.lottie.loadAnimation({ container: $('span', f), renderer: 'svg', loop: true, autoplay: true, animationData: data });
      anim.setSpeed(1.4);
      var W = window.innerWidth, from = goRight ? -170 : W + 20, to = goRight ? W + 20 : -170, flip = goRight ? '' : ' scaleX(-1)';
      var mv = f.animate([{ transform: 'translate(' + from + 'px,0)' + flip }, { transform: 'translate(' + (from + to) / 2 + 'px,-30px)' + flip }, { transform: 'translate(' + to + 'px,0)' + flip }], { duration: 4800 + Math.random() * 1600 });
      var done = function () { anim.destroy(); f.remove(); };
      mv.onfinish = done;
      f.addEventListener('click', function () {
        coins++; store.set('cb-coins', coins); $('#coins').textContent = coins;
        var c = $('.coins'); c.classList.remove('bump'); void c.offsetWidth; c.classList.add('bump');
        burstAt(f, ['+1', '🪙', '✦', 'nyan'], ['#FFD43B', '#3DD6FF', '#FF8A1F']);
        unlock('nyan');
        mv.cancel(); done();
      });
    });
  }
  if (!reduce) setTimeout(function loop() { spawnNyan(); setTimeout(loop, 10000 + Math.random() * 9000); }, 5000);

  /* ---------- cheat code: cat rain ---------- */
  var code = ['ArrowUp', 'ArrowUp', 'ArrowDown', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'ArrowLeft', 'ArrowRight', 'b', 'a'], pos = 0;
  window.addEventListener('keydown', function (e) {
    var k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    pos = k === code[pos] ? pos + 1 : (k === code[0] ? 1 : 0);
    if (pos === code.length) { pos = 0; catRain(); unlock('cheat'); }
  });
  function catRain() {
    if (reduce) return;
    var src = $('.chonk');
    for (var i = 0; i < 24; i++) {
      (function (i) {
        setTimeout(function () {
          var c = src.cloneNode(true);
          c.classList.add('rain'); c.classList.remove('chonk'); c.removeAttribute('width'); c.removeAttribute('height');
          c.style.left = (Math.random() * 100) + 'vw'; c.style.width = (50 + Math.random() * 70) + 'px';
          document.body.appendChild(c);
          c.animate([{ transform: 'translateY(0) rotate(0)' }, { transform: 'translateY(' + (window.innerHeight + 240) + 'px) rotate(' + (Math.random() > .5 ? 720 : -720) + 'deg)' }], { duration: 2200 + Math.random() * 1500, easing: 'ease-in' }).onfinish = function () { c.remove(); };
        }, i * 90);
      })(i);
    }
  }

  /* ---------- stat bars ---------- */
  $$('.stats i').forEach(function (bar) {
    var v = +getComputedStyle(bar).getPropertyValue('--v') || 0;
    for (var i = 0; i < 5; i++) { var b = document.createElement('b'); if (i < v) b.className = 'on'; bar.appendChild(b); }
  });
})();
