(function(){
var d=document,root=d.documentElement;root.classList.add('js');
var $=function(s){return d.querySelector(s)},$$=function(s){return [].slice.call(d.querySelectorAll(s))};
var reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;

/* nav */
var nav=$('#nav'),burger=$('#burger');
function setMenu(o){nav.classList.toggle('open',o);burger.setAttribute('aria-expanded',o);burger.setAttribute('aria-label',o?'Close menu':'Open menu')}
burger.addEventListener('click',function(){setMenu(!nav.classList.contains('open'))});
$$('#links a').forEach(function(a){a.addEventListener('click',function(){setMenu(false)})});
d.addEventListener('keydown',function(e){if(e.key==='Escape')setMenu(false)});

/* reveals */
var groups=new Map();
$$('[data-in]').forEach(function(el){var p=el.parentNode,n=groups.get(p)||0;if(!el.classList.contains('card'))el.style.setProperty('--d',(n*90)+'ms');groups.set(p,n+1)});
if('IntersectionObserver' in window){
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:.15});
  $$('[data-in]').forEach(function(el){io.observe(el)});
}else $$('[data-in]').forEach(function(el){el.classList.add('in')});

/* scroll: nav, story steps, floating button */
var pin=$('.pin'),shows=$$('.show'),story=$('#story'),steps=$$('.step'),flo=$('#float'),contact=$('#contact');
window.__story={i:0,p:0};
function onScroll(){
  var y=scrollY,vh=innerHeight;
  nav.classList.toggle('solid',y>40);
  var r=story.getBoundingClientRect(),span=r.height-vh;
  var p=span>0?Math.min(1,Math.max(0,-r.top/span)):0,i=Math.min(3,Math.floor(p*4));
  window.__story.p=p;
  if(i!==window.__story.i||!steps[i].classList.contains('on')){window.__story.i=i;pin.setAttribute('data-s',i);if(!reduce){steps.forEach(function(s,k){s.classList.toggle('on',k===i)});shows.forEach(function(s,k){s.classList.toggle('on',k===i)})}}
  var c=contact.getBoundingClientRect();
  flo.classList.toggle('on',y>vh*.8&&c.top>vh*.6);
}
var tick=false;
addEventListener('scroll',function(){if(!tick){tick=true;requestAnimationFrame(function(){tick=false;onScroll()})}},{passive:true});
addEventListener('resize',onScroll);onScroll();

/* airbrush parallax */
if(!reduce&&matchMedia('(pointer:fine)').matches){addEventListener('pointermove',function(e){root.style.setProperty('--mx',(e.clientX/innerWidth-.5).toFixed(3));root.style.setProperty('--my',(e.clientY/innerHeight-.5).toFixed(3))},{passive:true})}

/* PingBoard live status */
function setRow(el,m){
  if(!el)return;var s=el.querySelector('span');
  if(!m){el.className='';s.textContent='see live page';return}
  var up=/up|ok|operational|online/i.test(String(m.status));
  el.className=up?'up':'down';
  var u=m.uptime_24h;
  s.textContent=(up?'Up':'Down')+(u!=null?' · '+(Math.round(u*10)/10)+'% today':'');
}
function find(list,word){return list.filter(function(m){return String(m.name||'').toLowerCase().indexOf(word)>-1})[0]}
fetch('https://pingboard-backend.onrender.com/api/public/status/mohanraj/').then(function(r){if(!r.ok)throw 0;return r.json()}).then(function(j){
  var l=j.monitors||[];setRow($('#s-shop'),find(l,'shop'));setRow($('#s-ping'),find(l,'ping'));
}).catch(function(){setRow($('#s-shop'));setRow($('#s-ping'))});

/* ShopFlow race */
var btn=$('#race-btn'),msg=$('#race-msg'),stock=$('#stock'),buyers=$$('.buyer'),ran=false;
function reset(){ran=false;stock.textContent='1';msg.textContent='Both press Buy at the same time.';btn.textContent='Both press Buy';buyers.forEach(function(b){b.className='buyer';b.querySelector('span').textContent='waiting'})}
btn.addEventListener('click',function(){
  if(ran){reset();return}
  ran=true;btn.disabled=true;
  buyers.forEach(function(b){b.querySelector('span').textContent='pressing Buy…'});
  msg.textContent='Two orders arrive in the same moment…';
  setTimeout(function(){
    var w=Math.random()<.5?0:1,l=1-w;
    buyers[w].classList.add('won');buyers[w].querySelector('span').textContent='order placed';
    buyers[l].classList.add('lost');buyers[l].querySelector('span').textContent='sold out';
    stock.textContent='0';
    msg.textContent='Buyer '+'AB'[w]+' locked the stock first and got it. Buyer '+'AB'[l]+' was told it sold out. Nobody was charged for nothing.';
    btn.textContent='Run it again';btn.disabled=false;
  },reduce?0:900);
});

/* copy email */
var toast=$('#toast'),tt;
function say(t){toast.textContent=t;toast.classList.add('on');clearTimeout(tt);tt=setTimeout(function(){toast.classList.remove('on')},1800)}
$('#copy').addEventListener('click',function(){
  var m='mohanrajtunes@gmail.com';
  (navigator.clipboard?navigator.clipboard.writeText(m):Promise.reject()).then(function(){say('Email copied')}).catch(function(){say(m)});
});
})();
